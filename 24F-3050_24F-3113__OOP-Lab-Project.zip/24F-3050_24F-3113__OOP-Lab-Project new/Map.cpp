#include <iostream>
#include "Stronghold.h"

using namespace std;

Map::Map() : positionCount(0) {
    for (int i = 0; i < MAP_SIZE; i++) {
        for (int j = 0; j < MAP_SIZE; j++) {
            grid[i][j] = 0;
        }
    }
    for (int i = 0; i < MAX_TREATIES; i++) {
        positions[i].playerID = 0;
        positions[i].x = 0;
        positions[i].y = 0;
    }
}

void Map::moveArmy(int playerID, int newX, int newY) {
    if (newX < 0 || newX >= MAP_SIZE || newY < 0 || newY >= MAP_SIZE) {
        cout << "Invalid coordinates." << endl;
        return;
    }
    for (int i = 0; i < positionCount; i++) {
        if (positions[i].playerID == playerID) {
            grid[positions[i].x][positions[i].y] = 0;
            positions[i].x = newX;
            positions[i].y = newY;
            grid[newX][newY] = playerID;
            cout << "Army moved to (" << newX << "," << newY << ")." << endl;
            return;
        }
    }
    if (positionCount < MAX_TREATIES) {
        positions[positionCount].playerID = playerID;
        positions[positionCount].x = newX;
        positions[positionCount].y = newY;
        grid[newX][newY] = playerID;
        positionCount++;
        cout << "Army moved to (" << newX << "," << newY << ")." << endl;
    }
    else {
        cout << "Position limit reached." << endl;
    }
}

void Map::displayMap() const {
    cout << "---- Map ----" << endl;
    for (int i = 0; i < MAP_SIZE; i++) {
        for (int j = 0; j < MAP_SIZE; j++) {
            cout << grid[i][j] << " ";
        }
        cout << endl;
    }
}