#include <iostream>
#include "Stronghold.h"

using namespace std;

SocialClass::SocialClass(const string& name, int pop) : className(name), population(pop) {}

void SocialClass::addPeople(int count) {
    if (count >= 0) {
        population += count;
    }
}

void SocialClass::displayStatus() const {
    cout << className << ": " << population << endl;
}

Nobles::Nobles(int pop) : SocialClass("Nobles", pop) {}

void Nobles::addPeople(int count) {
    if (count >= 0 && population + count <= MAX_NOBLES) {
        population += count;
    }
    else {
        cout << "Cannot add nobles: Limit reached or invalid count." << endl;
    }
}

Merchants::Merchants(int pop) : SocialClass("Merchants", pop) {}

void Merchants::addPeople(int count) {
    if (count >= 0 && population + count <= MAX_MERCHANTS) {
        population += count;
    }
    else {
        cout << "Cannot add merchants: Limit reached or invalid count." << endl;
    }
}

Peasants::Peasants(int pop) : SocialClass("Peasants", pop) {}

void Peasants::addPeople(int count) {
    if (count >= 0 && population + count <= MAX_PEASANTS) {
        population += count;
    }
    else {
        cout << "Cannot add peasants: Limit reached or invalid count." << endl;
    }
}

Slaves::Slaves(int pop) : SocialClass("Slaves", pop) {}

void Slaves::addPeople(int count) {
    if (count >= 0 && population + count <= MAX_SLAVES) {
        population += count;
    }
    else {
        cout << "Cannot add slaves: Limit reached or invalid count." << endl;
    }
}

SocialStructure::SocialStructure() : nobles(0), merchants(0), peasants(0), slaves(0) {}

void SocialStructure::addNobles(int count) {
    nobles.addPeople(count);
}

void SocialStructure::addMerchants(int count) {
    merchants.addPeople(count);
}

void SocialStructure::addPeasants(int count) {
    peasants.addPeople(count);
}

void SocialStructure::addSlaves(int count) {
    slaves.addPeople(count);
}

void SocialStructure::displayStatus() const {
    nobles.displayStatus();
    merchants.displayStatus();
    peasants.displayStatus();
    slaves.displayStatus();
}

void SocialStructure::setPopulations(int n, int m, int p, int s) {
    nobles = Nobles(n);
    merchants = Merchants(m);
    peasants = Peasants(p);
    slaves = Slaves(s);
}