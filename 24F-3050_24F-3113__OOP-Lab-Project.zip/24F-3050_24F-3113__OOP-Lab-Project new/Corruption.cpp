

#include <iostream>
#include "Stronghold.h"

using namespace std;

Corruption::Corruption() {
    corruptionLevel = 0; 
}

void Corruption::increaseCorruption(int amount) {
    if (amount > 0) {
        corruptionLevel += amount;
        if (corruptionLevel > 100) corruptionLevel = 100;
        cout << "Corruption increased by " << amount << ". Current level: " << corruptionLevel << endl;
    }
    else {
        cout << "Invalid amount to increase corruption." << endl;
    }
}

void Corruption::decreaseCorruption(int amount) {
    if (amount > 0) {
        corruptionLevel -= amount;
        if (corruptionLevel < 0) corruptionLevel = 0;
        cout << "Corruption decreased by " << amount << ". Current level: " << corruptionLevel << endl;
    }
    else {
        cout << "Invalid amount to decrease corruption." << endl;
    }
}

void Corruption::displayStatus() const {
    cout << "Corruption Level: " << corruptionLevel << endl;
}
