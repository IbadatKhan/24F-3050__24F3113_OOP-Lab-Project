#include <iostream>
#include "Stronghold.h"

using namespace std;

Market::Market(Kingdom* k, int max) : kingdoms(k), maxKingdoms(max) {}

bool Market::tradeResources(int player1, int player2, ResourceType type1, int amount1, ResourceType type2, int amount2) {
    if (amount1 <= 0 || amount2 <= 0) {
        cout << "Invalid trade amounts." << endl;
        return false;
    }
    Kingdom* k1 = nullptr;
    Kingdom* k2 = nullptr;
    for (int i = 0; i < maxKingdoms; i++) {
        if (kingdoms[i].getPlayerID() == player1) k1 = &kingdoms[i];
        if (kingdoms[i].getPlayerID() == player2) k2 = &kingdoms[i];
    }
    if (!k1 || !k2 || player1 == player2) {
        cout << "Invalid player IDs." << endl;
        return false;
    }

    if (k1->getResources().getResource(type1) < amount1 || k2->getResources().getResource(type2) < amount2) {
        cout << "Insufficient resources for trade." << endl;
        return false;
    }

    k1->getResources().consumeResources(type1 == FOOD ? amount1 : 0, type1 == WOOD ? amount1 : 0,
        type1 == STONE ? amount1 : 0, type1 == IRON ? amount1 : 0);
    k1->getResources().gatherResources(type2 == FOOD ? amount2 : 0, type2 == WOOD ? amount2 : 0,
        type2 == STONE ? amount2 : 0, type2 == IRON ? amount2 : 0);
    k2->getResources().consumeResources(type2 == FOOD ? amount2 : 0, type2 == WOOD ? amount2 : 0,
        type2 == STONE ? amount2 : 0, type2 == IRON ? amount2 : 0);
    k2->getResources().gatherResources(type1 == FOOD ? amount1 : 0, type1 == WOOD ? amount1 : 0,
        type1 == STONE ? amount1 : 0, type1 == IRON ? amount1 : 0);

    string log = "player" + to_string(player1) + "->player" + to_string(player2) + ":traded_" +
        to_string(amount1) + "_" + to_string(type1) + "_for_" + to_string(amount2) + "_" + to_string(type2);
    GameSaver::logMarket(log);
    cout << "Trade successful." << endl;
    return true;
}

bool Market::smuggleResources(int player1, int player2, ResourceType type, int amount) {
    if (amount <= 0) {
        cout << "Invalid smuggling amount." << endl;
        return false;
    }
    Kingdom* k1 = nullptr;
    Kingdom* k2 = nullptr;
    for (int i = 0; i < maxKingdoms; i++) {
        if (kingdoms[i].getPlayerID() == player1) k1 = &kingdoms[i];
        if (kingdoms[i].getPlayerID() == player2) k2 = &kingdoms[i];
    }
    if (!k1 || !k2 || player1 == player2) {
        cout << "Invalid player IDs." << endl;
        return false;
    }

    if (k1->getResources().getResource(type) < amount) {
        cout << "Insufficient resources to smuggle." << endl;
        return false;
    }
    if (rand() % 10 == 0) {
        k1->getPopulation().updateUnrest();
        string log = "player" + to_string(player1) + "->player" + to_string(player2) + ":smuggled_" +
            to_string(amount) + "_" + to_string(type) + "_failed";
        GameSaver::logMarket(log);
        cout << "Smuggling failed, unrest increased." << endl;
        return false;
    }

    k1->getResources().consumeResources(type == FOOD ? amount : 0, type == WOOD ? amount : 0,
        type == STONE ? amount : 0, type == IRON ? amount : 0);
    k2->getResources().gatherResources(type == FOOD ? amount : 0, type == WOOD ? amount : 0,
        type == STONE ? amount : 0, type == IRON ? amount : 0);
    string log = "player" + to_string(player1) + "->player" + to_string(player2) + ":smuggled_" +
        to_string(amount) + "_" + to_string(type);
    GameSaver::logMarket(log);
    cout << "Smuggling successful." << endl;
    return true;
}