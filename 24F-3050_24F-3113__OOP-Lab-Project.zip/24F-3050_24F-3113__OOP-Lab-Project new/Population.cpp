#include <iostream>
#include "Stronghold.h"

using namespace std;

Population::Population() {
    totalPeople = 100;
    births = 0;
    deaths = 0;
    unrestLevel = 0;
}

void Population::grow(int amount) {
    if (amount > 0) {
        if (amount > 100) {
            cout << "Warning: Unusually high birth rate (" << amount << ")!" << endl; // Updated for Phase 2: Use endl
        }
        totalPeople += amount;
        births += amount;
    }
}

void Population::die(int amount) {
    if (amount > 0 && amount <= totalPeople) {
        totalPeople -= amount;
        deaths += amount;
    }
}

void Population::updateUnrest() {
    if (totalPeople < 50) {
        unrestLevel = 3;
    }
    else if (totalPeople < 80) {
        unrestLevel = 2;
    }
    else {
        unrestLevel = 0;
    }
}

void Population::displayStatus() const {
    cout << "Total People: " << totalPeople << endl;
    cout << "Births: " << births << ", Deaths: " << deaths << endl;
    cout << "Unrest Level: " << unrestLevel;
    if (unrestLevel == 0) cout << " (Peaceful)" << endl;
    else if (unrestLevel == 2) cout << " (Tension)" << endl;
    else cout << " (Possible Revolt!)" << endl;
}