#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Stronghold.h"

using namespace std;

Communication::Communication() : messageCount(0) {
    for (int i = 0; i < MAX_MESSAGES; i++) {
        messages[i].senderID = 0;
        messages[i].receiverID = 0;
        messages[i].content[0] = '\0';
    }
}

void Communication::sendMessage(int senderID, int receiverID, const string& message) {
    if (messageCount < MAX_MESSAGES) {
        messages[messageCount].senderID = senderID;
        messages[messageCount].receiverID = receiverID;
        strncpy(messages[messageCount].content, message.c_str(), 99);
        messages[messageCount].content[99] = '\0';
        string log = "player" + to_string(senderID) + "->player" + to_string(receiverID) + ":" + message;
        GameSaver::logChat(log);
        messageCount++;
        cout << "Message sent." << endl;
    }
    else {
        cout << "Message limit reached." << endl;
    }
}

void Communication::displayMessages(int playerID) const {
    bool hasMessages = false;
    for (int i = 0; i < messageCount; i++) {
        if (messages[i].receiverID == playerID) {
            cout << "From player" << messages[i].senderID << ": " << messages[i].content << endl;
            hasMessages = true;
        }
    }
    if (!hasMessages) {
        cout << "No messages received." << endl;
    }
}