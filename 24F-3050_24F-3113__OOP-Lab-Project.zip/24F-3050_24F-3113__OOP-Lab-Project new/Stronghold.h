#ifndef STRONGHOLD_H
#define STRONGHOLD_H

#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

const int MAX_NOBLES = 100;
const int MAX_MERCHANTS = 100;
const int MAX_PEASANTS = 1000;
const int MAX_SLAVES = 500;
const int MAX_MESSAGES = 100;
const int MAX_TREATIES = 50;
const int MAP_SIZE = 5;

enum ResourceType { FOOD = 0, WOOD = 1, STONE = 2, IRON = 3 };

class SocialClass {
protected:
    int population;
    string className;
public:
    SocialClass(const string& name, int pop = 0);
    virtual void addPeople(int count);
    virtual void displayStatus() const;
    virtual ~SocialClass() = default;
    int getPopulation() const { return population; }
};

class Nobles : public SocialClass {
public:
    Nobles(int pop = 0);
    void addPeople(int count) override;
};

class Merchants : public SocialClass {
public:
    Merchants(int pop = 0);
    void addPeople(int count) override;
};

class Peasants : public SocialClass {
public:
    Peasants(int pop = 0);
    void addPeople(int count) override;
};

class Slaves : public SocialClass {
public:
    Slaves(int pop = 0);
    void addPeople(int count) override;
};

class SocialStructure {
private:
    Nobles nobles;
    Merchants merchants;
    Peasants peasants;
    Slaves slaves;
public:
    SocialStructure();
    void addNobles(int count);
    void addMerchants(int count);
    void addPeasants(int count);
    void addSlaves(int count);
    void displayStatus() const;
    void setPopulations(int n, int m, int p, int s);
    int getNobles() const { return nobles.getPopulation(); }
    int getMerchants() const { return merchants.getPopulation(); }
    int getPeasants() const { return peasants.getPopulation(); }
    int getSlaves() const { return slaves.getPopulation(); }
};

class Population {
private:
    int totalPeople;
    int births;
    int deaths;
    int unrestLevel;
public:
    Population();
    void grow(int births);
    void die(int deaths);
    void updateUnrest();
    void displayStatus() const;
    int getTotal() const { return totalPeople; }
};

class Army {
private:
    int totalSoldiers;
    int trainedSoldiers;
    int morale;
public:
    Army();
    void recruit(int recruits);
    void train(int trainingSessions);
    void updateMorale();
    void displayStatus() const;
    void applyCasualties(int losses);
    int getStrength() const;
    int getTotalSoldiers() const { return totalSoldiers; }
    int getTrainedSoldiers() const { return trainedSoldiers; }
};

class Leader {
private:
    string name;
    int leadershipLevel;
    int popularity;
public:
    Leader();
    void setName(const string& leaderName);
    void improveLeadership(int amount);
    void changePopularity(int amount);
    void displayStatus() const;
    int getPopularity() const;
    int getLeadershipLevel() const { return leadershipLevel; }
};

class Economy {
private:
    int gold;
    int food;
public:
    Economy();
    void addGold(int amount);
    void spendGold(int amount);
    void addFood(int amount);
    void consumeFood(int amount);
    void displayStatus() const;
    int getGold() const;
    void setGold(int amount);
    int getFood() const { return food; }
};

class Banking {
private:
    int totalLoans;
    int interestRate;
public:
    Banking();
    void issueLoan(int amount);
    void repayLoan(int amount);
    void adjustInterestRate(int newRate);
    void displayStatus() const;
    void setLoans(int loans) { totalLoans = loans; }
    void setInterestRate(int rate) { interestRate = rate; }
    int getLoans() const { return totalLoans; }
    int getInterestRate() const { return interestRate; }
};

class Corruption {
private:
    int corruptionLevel;
public:
    Corruption();
    void increaseCorruption(int amount);
    void decreaseCorruption(int amount);
    void displayStatus() const;
    void setCorruptionLevel(int level) { corruptionLevel = level; }
    int getCorruptionLevel() const { return corruptionLevel; }
};

class Defense {
private:
    int wallStrength;
    int towerCount;
    int trapEfficiency;
public:
    Defense();
    void upgradeWalls(int amount);
    void addTowers(int count);
    void improveTraps(int amount);
    void displayStatus() const;
    void setDefenses(int walls, int towers, int traps) {
        wallStrength = walls;
        towerCount = towers;
        trapEfficiency = traps;
    }
    int getWallStrength() const { return wallStrength; }
    int getTowerCount() const { return towerCount; }
    int getTrapEfficiency() const { return trapEfficiency; }
};

class ResourceEcosystem {
private:
    int food;
    int wood;
    int stone;
    int iron;
public:
    ResourceEcosystem();
    void gatherFood(int amount);
    void gatherWood(int amount);
    void gatherStone(int amount);
    void gatherIron(int amount);
    void consumeFood(int amount);
    void consumeWood(int amount);
    void consumeStone(int amount);
    void consumeIron(int amount);
    void displayStatus() const;
    void gatherResources(int f, int w, int s, int i);
    void consumeResources(int f, int w, int s, int i);
    void tradeResources(int& gold, int f, int w, int s, int i);
    int getFood() const { return food; }
    int getWood() const { return wood; }
    int getStone() const { return stone; }
    int getIron() const { return iron; }
    int getResource(ResourceType type) const;
};

// Forward declarations for GameSaver
class Kingdom;
class Population;
class Economy;
class ResourceEcosystem;

class GameSaver {
public:
    static void saveGame(const string& filename, const Population& pop, const Economy& econ, const ResourceEcosystem& res);
    static void loadGame(const string& filename, Population& pop, Economy& econ, ResourceEcosystem& res);
    static void saveGame(const string& filename, const Kingdom* kingdoms, int maxKingdoms);
    static void loadGame(const string& filename, Kingdom* kingdoms, int maxKingdoms);
    static void logChat(const string& message);
    static void logTreaty(const string& treaty);
    static void logMarket(const string& transaction);
};

class Kingdom {
private:
    int playerID;
    ResourceEcosystem resources;
    Army army;
    Population population;
    Economy economy;
    Leader leader;
    SocialStructure socialStructure;
    Banking banking;
    Corruption corruption;
    Defense defense;
public:
    Kingdom(int id);
    int getPlayerID() const;
    ResourceEcosystem& getResources() const;
    Army& getArmy() const;
    Population& getPopulation() const;
    Economy& getEconomy() const;
    Leader& getLeader() const;
    SocialStructure& getSocialStructure() const;
    Banking& getBanking() const;
    Corruption& getCorruption() const;
    Defense& getDefense() const;
};

class Communication {
private:
    struct Message {
        int senderID;
        int receiverID;
        char content[100];
    };
    Message messages[MAX_MESSAGES];
    int messageCount;
public:
    Communication();
    void sendMessage(int senderID, int receiverID, const string& message);
    void displayMessages(int playerID) const;
};

class Alliance {
private:
    struct Treaty {
        int id;
        int player1;
        int player2;
        char terms[100];
    };
    Treaty treaties[MAX_TREATIES];
    int treatyCount;
    int nextID;
public:
    Alliance();
    void formAlliance(int player1, int player2, const string& terms);
    void breakAlliance(int allianceID, Kingdom* kingdoms, int maxKingdoms);
    void displayAlliances(int playerID) const;
};

class Market {
private:
    Kingdom* kingdoms;
    int maxKingdoms;
public:
    Market(Kingdom* k, int max);
    bool tradeResources(int player1, int player2, ResourceType type1, int amount1, ResourceType type2, int amount2);
    bool smuggleResources(int player1, int player2, ResourceType type, int amount);
};

class Conflict {
private:
    Kingdom* kingdoms;
    int maxKingdoms;
public:
    Conflict(Kingdom* k, int max);
    bool startBattle(int attackerID, int defenderID);
    bool betrayAlliance(int attackerID, int allyID);
};

class Map {
private:
    int grid[MAP_SIZE][MAP_SIZE];
    struct ArmyPosition {
        int playerID;
        int x, y;
    };
    ArmyPosition positions[MAX_TREATIES];
    int positionCount;
public:
    Map();
    void moveArmy(int playerID, int newX, int newY);
    void displayMap() const;
};

#endif