#include <iostream>
#include "Stronghold.h"

using namespace std;

Army::Army() {
    totalSoldiers = 50;
    trainedSoldiers = 20;
    morale = 70;
}

void Army::recruit(int number) {
    if (number > 0) {
        totalSoldiers += number;
        cout << number << " soldiers recruited." << endl;
    }
}

void Army::train(int number) {
    if (number > 0 && number <= totalSoldiers - trainedSoldiers) {
        trainedSoldiers += number;
        morale += static_cast<int>(number * 0.5);
        if (morale > 100) morale = 100;
        cout << number << " soldiers trained." << endl;
    }
}

void Army::updateMorale() {
    if (trainedSoldiers < totalSoldiers / 2) {
        morale -= 10;
    }
    else {
        morale += 5;
    }
    if (morale < 0) morale = 0;
    if (morale > 100) morale = 100;
}

void Army::displayStatus() const {
    cout << "Total Soldiers: " << totalSoldiers << endl;
    cout << "Trained Soldiers: " << trainedSoldiers << endl;
    cout << "Morale: " << morale << "/100" << endl;
}

void Army::applyCasualties(int losses) {
    if (losses > 0) {
        totalSoldiers = totalSoldiers - losses;
        if (totalSoldiers < 0) totalSoldiers = 0;
        if (trainedSoldiers > totalSoldiers) {
            trainedSoldiers = totalSoldiers;
        }
        cout << "Lost " << losses << " soldiers in battle." << endl;
    }
}

// Added for Phase 2: Get army strength for battle calculations
int Army::getStrength() const {
    return totalSoldiers + trainedSoldiers * 2;
}