#include <iostream>
#include <cstdlib>
#include "Stronghold.h"

using namespace std;

Conflict::Conflict(Kingdom* k, int max) : kingdoms(k), maxKingdoms(max) {}

bool Conflict::startBattle(int attackerID, int defenderID) {
    if (attackerID == defenderID) {
        cout << "Cannot attack self." << endl;
        return false;
    }
    Kingdom* attacker = nullptr;
    Kingdom* defender = nullptr;
    for (int i = 0; i < maxKingdoms; i++) {
        if (kingdoms[i].getPlayerID() == attackerID) attacker = &kingdoms[i];
        if (kingdoms[i].getPlayerID() == defenderID) defender = &kingdoms[i];
    }
    if (!attacker || !defender) {
        cout << "Invalid player IDs." << endl;
        return false;
    }

    int attackerScore = attacker->getArmy().getStrength();
    int defenderScore = defender->getArmy().getStrength();
    if (attackerScore <= 0 || defenderScore <= 0) {
        cout << "No soldiers to fight." << endl;
        return false;
    }

    int total = attackerScore + defenderScore;
    int chance = (attackerScore * 100) / total;
    if (rand() % 100 < chance) {
        defender->getArmy().applyCasualties(defenderScore / 2);
        defender->getPopulation().die(defender->getPopulation().getTotal() / 10);
        attacker->getResources().consumeFood(attackerScore / 10);
        attacker->getArmy().updateMorale();
        cout << "Attack successful." << endl;
        return true;
    }
    else {
        attacker->getArmy().applyCasualties(attackerScore / 2);
        attacker->getPopulation().die(attacker->getPopulation().getTotal() / 10);
        defender->getResources().consumeFood(defenderScore / 10);
        defender->getArmy().updateMorale();
        cout << "Attack failed." << endl;
        return false;
    }
}

bool Conflict::betrayAlliance(int attackerID, int allyID) {
    bool success = startBattle(attackerID, allyID);
    for (int i = 0; i < maxKingdoms; i++) {
        if (kingdoms[i].getPlayerID() == attackerID) {
            kingdoms[i].getPopulation().updateUnrest();
            break;
        }
    }
    if (success) {
        cout << "Betrayal successful." << endl;
    }
    else {
        cout << "Betrayal failed." << endl;
    }
    return success;
}