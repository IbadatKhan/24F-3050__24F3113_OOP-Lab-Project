

#include <iostream>
#include "Stronghold.h"

using namespace std;

Banking::Banking() {
    totalLoans = 0;
    interestRate = 5; 
}

void Banking::issueLoan(int amount) {
    if (amount > 0) {
        totalLoans += amount;
        cout << "Issued a loan of " << amount << " gold. Total loans: " << totalLoans << endl;
    }
    else {
        cout << "Invalid loan amount." << endl;
    }
}

void Banking::repayLoan(int amount) {
    if (amount > 0 && amount <= totalLoans) {
        totalLoans -= amount;
        cout << "Repaid " << amount << " gold. Remaining loans: " << totalLoans << endl;
    }
    else {
        cout << "Invalid repayment amount." << endl;
    }
}

void Banking::adjustInterestRate(int newRate) {
    if (newRate >= 0 && newRate <= 100) {
        interestRate = newRate;
        cout << "Interest rate adjusted to " << interestRate << "%" << endl;
    }
    else {
        cout << "Invalid interest rate." << endl;
    }
}

void Banking::displayStatus() const {
    cout << "Total Loans: " << totalLoans << " gold" << endl;
    cout << "Interest Rate: " << interestRate << "%" << endl;
}
