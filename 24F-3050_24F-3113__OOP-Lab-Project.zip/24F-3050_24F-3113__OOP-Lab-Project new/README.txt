StrongHold Phase 2
   To compile: g++ main.cpp Army.cpp Banking.cpp Corruption.cpp Defense.cpp Economy.cpp GameSaver.cpp Leader.cpp Population.cpp ResourceEcosystem.cpp SocialStructure.cpp Kingdom.cpp Communication.cpp Alliance.cpp Market.cpp Conflict.cpp Map.cpp -o Stronghold
   To run: ./Stronghold
   Menu options:
   1-3: Manage population
   4-6: Manage army
   7-10: Manage leader
   11-15: Manage economy
   16-19: Banking (placeholder)
   20-22: Corruption (placeholder)
   23-27: Manage social structure
   28-31: Defense (placeholder)
   32-35: Manage resources
   36: Save game
   37: Load game (placeholder)
   38: Simulate battle losses
   39: Send message
   40: View messages
   41: Form alliance
   42: Break alliance
   43: Trade resources (player)
   44: Smuggle resources
   45: Attack player
   46: Betray alliance
   47: Move army
   48: Display map
   49: Exit
   Output files:
   - save.txt: Game state
   - chat_log.txt: Messages
   - treaty_log.txt: Alliances
   - market_log.txt: Trades/smuggling