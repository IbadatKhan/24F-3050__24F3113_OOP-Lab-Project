#include <iostream>
#include <fstream>
#include "Stronghold.h"

using namespace std;

void GameSaver::saveGame(const string& filename, const Population& pop, const Economy& econ, const ResourceEcosystem& res) {
    ofstream out(filename);
    if (out) {
        out << pop.getTotal() << " "
            << econ.getGold() << " "
            << econ.getFood() << " "
            << res.getFood() << " "
            << res.getWood() << " "
            << res.getStone() << " "
            << res.getIron() << endl;
        out.close();
    }
    else {
        cout << "Error: Cannot open " << filename << endl;
    }
}

void GameSaver::loadGame(const string& filename, Population& pop, Economy& econ, ResourceEcosystem& res) {
    ifstream in(filename);
    if (in) {
        int totalPop, gold, econFood, resFood, wood, stone, iron;
        in >> totalPop >> gold >> econFood >> resFood >> wood >> stone >> iron;
        pop = Population();
        pop.grow(totalPop);
        econ = Economy();
        econ.setGold(gold);
        econ.addFood(econFood);
        res = ResourceEcosystem();
        res.gatherResources(resFood, wood, stone, iron);
        in.close();
    }
    else {
        cout << "Error: Cannot open " << filename << endl;
    }
}

void GameSaver::saveGame(const string& filename, const Kingdom* kingdoms, int maxKingdoms) {
    ofstream out(filename);
    if (out) {
        for (int i = 0; i < maxKingdoms; i++) {
            out << "player" << kingdoms[i].getPlayerID() << ":"
                << kingdoms[i].getPopulation().getTotal() << " "
                << kingdoms[i].getEconomy().getGold() << " "
                << kingdoms[i].getEconomy().getFood() << " "
                << kingdoms[i].getResources().getFood() << " "
                << kingdoms[i].getResources().getWood() << " "
                << kingdoms[i].getResources().getStone() << " "
                << kingdoms[i].getResources().getIron() << " "
                << kingdoms[i].getArmy().getStrength() << " "
                << kingdoms[i].getArmy().getTotalSoldiers() << " "
                << kingdoms[i].getArmy().getTrainedSoldiers() << " "
                << kingdoms[i].getLeader().getPopularity() << " "
                << kingdoms[i].getLeader().getLeadershipLevel() << " "
                << kingdoms[i].getSocialStructure().getNobles() << " "
                << kingdoms[i].getSocialStructure().getMerchants() << " "
                << kingdoms[i].getSocialStructure().getPeasants() << " "
                << kingdoms[i].getSocialStructure().getSlaves() << " "
                << kingdoms[i].getBanking().getLoans() << " "
                << kingdoms[i].getBanking().getInterestRate() << " "
                << kingdoms[i].getCorruption().getCorruptionLevel() << " "
                << kingdoms[i].getDefense().getWallStrength() << " "
                << kingdoms[i].getDefense().getTowerCount() << " "
                << kingdoms[i].getDefense().getTrapEfficiency() << endl;
        }
        out.close();
    }
    else {
        cout << "Error: Cannot open " << filename << endl;
    }
}

void GameSaver::loadGame(const string& filename, Kingdom* kingdoms, int maxKingdoms) {
    ifstream in(filename);
    if (in) {
        for (int i = 0; i < maxKingdoms; i++) {
            string playerTag;
            int totalPop, gold, econFood, resFood, wood, stone, iron, strength, totalSoldiers, trainedSoldiers,
                popularity, leadershipLevel, nobles, merchants, peasants, slaves, loans, interestRate, corruptionLevel,
                wallStrength, towerCount, trapEfficiency;
            char colon;
            in >> playerTag >> totalPop >> gold >> econFood >> resFood >> wood >> stone >> iron >> strength
                >> totalSoldiers >> trainedSoldiers >> popularity >> leadershipLevel >> nobles >> merchants
                >> peasants >> slaves >> loans >> interestRate >> corruptionLevel >> wallStrength >> towerCount
                >> trapEfficiency;
            kingdoms[i].getPopulation() = Population();
            kingdoms[i].getPopulation().grow(totalPop);
            kingdoms[i].getEconomy() = Economy();
            kingdoms[i].getEconomy().setGold(gold);
            kingdoms[i].getEconomy().addFood(econFood);
            kingdoms[i].getResources() = ResourceEcosystem();
            kingdoms[i].getResources().gatherResources(resFood, wood, stone, iron);
            kingdoms[i].getArmy() = Army();
            kingdoms[i].getArmy().recruit(totalSoldiers);
            kingdoms[i].getArmy().train(trainedSoldiers);
            kingdoms[i].getLeader() = Leader();
            kingdoms[i].getLeader().changePopularity(popularity);
            kingdoms[i].getLeader().improveLeadership(leadershipLevel);
            kingdoms[i].getSocialStructure() = SocialStructure();
            kingdoms[i].getSocialStructure().setPopulations(nobles, merchants, peasants, slaves);
            kingdoms[i].getBanking() = Banking();
            kingdoms[i].getBanking().setLoans(loans);
            kingdoms[i].getBanking().setInterestRate(interestRate);
            kingdoms[i].getCorruption() = Corruption();
            kingdoms[i].getCorruption().setCorruptionLevel(corruptionLevel);
            kingdoms[i].getDefense() = Defense();
            kingdoms[i].getDefense().setDefenses(wallStrength, towerCount, trapEfficiency);
        }
        in.close();
    }
    else {
        cout << "Error: Cannot open " << filename << endl;
    }
}

void GameSaver::logChat(const string& message) {
    ofstream out("chat_log.txt", ios::app);
    if (out) {
        out << message << endl;
        out.close();
    }
    else {
        cout << "Error: Cannot open chat_log.txt" << endl;
    }
}

void GameSaver::logTreaty(const string& treaty) {
    ofstream out("treaty_log.txt", ios::app);
    if (out) {
        out << treaty << endl;
        out.close();
    }
    else {
        cout << "Error: Cannot open treaty_log.txt" << endl;
    }
}

void GameSaver::logMarket(const string& transaction) {
    ofstream out("market_log.txt", ios::app);
    if (out) {
        out << transaction << endl;
        out.close();
    }
    else {
        cout << "Error: Cannot open market_log.txt" << endl;
    }
}