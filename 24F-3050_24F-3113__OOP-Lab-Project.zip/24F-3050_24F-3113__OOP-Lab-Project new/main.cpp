#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Stronghold.h"

using namespace std;

const int MAX_KINGDOMS = 2;

void checkRandomEvent(Economy& econ, Population& pop, Army& army) {
    if (rand() % 5 == 0) {
        int event = rand() % 4;
        switch (event) {
        case 0:
            cout << "EVENT: Gold mine discovered! +50 gold." << endl;
            econ.addGold(50);
            break;
        case 1:
            cout << "EVENT: Minor plague! -10 population." << endl;
            pop.die(10);
            break;
        case 2:
            cout << "EVENT: Training accident! -5 soldiers." << endl;
            army.applyCasualties(5);
            break;
        case 3:
            cout << "EVENT: Bountiful harvest! +100 food" << endl;
            econ.addFood(100);
            break;
        }
    }
}

int main() {
    Kingdom kingdoms[MAX_KINGDOMS] = { Kingdom(1), Kingdom(2) };
    Communication comm;
    Alliance alliance;
    Market market(kingdoms, MAX_KINGDOMS);
    Conflict conflict(kingdoms, MAX_KINGDOMS);
    Map map;
    int choice, player = 0;

    srand(static_cast<unsigned int>(time(0)));

    do {
        cout << "--- Player " << kingdoms[player].getPlayerID() << " Kingdom Management Menu ---" << endl;
        cout << "1. Add Births" << endl;
        cout << "2. Add Deaths" << endl;
        cout << "3. Show Population Status" << endl;
        cout << "4. Recruit Soldiers" << endl;
        cout << "5. Train Soldiers" << endl;
        cout << "6. Show Army Status" << endl;
        cout << "7. Set Leader Name" << endl;
        cout << "8. Improve Leadership" << endl;
        cout << "9. Change Popularity" << endl;
        cout << "10. Show Leader Status" << endl;
        cout << "11. Add Gold" << endl;
        cout << "12. Spend Gold" << endl;
        cout << "13. Add Food" << endl;
        cout << "14. Consume Food" << endl;
        cout << "15. Show Economy Status" << endl;
        cout << "16. Issue Loan" << endl;
        cout << "17. Repay Loan" << endl;
        cout << "18. Adjust Interest Rate" << endl;
        cout << "19. Show Banking Status" << endl;
        cout << "20. Increase Corruption" << endl;
        cout << "21. Decrease Corruption" << endl;
        cout << "22. Show Corruption Status" << endl;
        cout << "23. Add Nobles" << endl;
        cout << "24. Add Merchants" << endl;
        cout << "25. Add Peasants" << endl;
        cout << "26. Add Slaves" << endl;
        cout << "27. Show Social Structure Status" << endl;
        cout << "28. Upgrade Walls" << endl;
        cout << "29. Add Towers" << endl;
        cout << "30. Improve Traps" << endl;
        cout << "31. Show Defense Status" << endl;
        cout << "32. Gather Resources" << endl;
        cout << "33. Consume Resources" << endl;
        cout << "34. Trade Resources (Internal)" << endl;
        cout << "35. Show Resource Status" << endl;
        cout << "36. Save Game" << endl;
        cout << "37. Load Game" << endl;
        cout << "38. Simulate Battle Losses" << endl;
        cout << "39. Send Message" << endl;
        cout << "40. View Messages" << endl;
        cout << "41. Form Alliance" << endl;
        cout << "42. Break Alliance" << endl;
        cout << "43. Trade Resources (Player)" << endl;
        cout << "44. Smuggle Resources" << endl;
        cout << "45. Attack Player" << endl;
        cout << "46. Betray Alliance" << endl;
        cout << "47. Move Army" << endl;
        cout << "48. Display Map" << endl;
        cout << "49. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            int b;
            cout << "Enter number of births: ";
            cin >> b;
            kingdoms[player].getPopulation().grow(b);
            break;
        }
        case 2: {
            int d;
            cout << "Enter number of deaths: ";
            cin >> d;
            kingdoms[player].getPopulation().die(d);
            break;
        }
        case 3:
            kingdoms[player].getPopulation().updateUnrest();
            kingdoms[player].getPopulation().displayStatus();
            break;
        case 4: {
            int r;
            cout << "Enter number of soldiers to recruit: ";
            cin >> r;
            kingdoms[player].getArmy().recruit(r);
            break;
        }
        case 5: {
            int t;
            cout << "Enter number of soldiers to train: ";
            cin >> t;
            kingdoms[player].getArmy().train(t);
            break;
        }
        case 6:
            kingdoms[player].getArmy().updateMorale();
            kingdoms[player].getArmy().displayStatus();
            break;
        case 7: {
            string name;
            cout << "Enter leader's name: ";
            cin.ignore();
            getline(cin, name);
            kingdoms[player].getLeader().setName(name);
            break;
        }
        case 8: {
            int amount;
            cout << "Enter amount to improve leadership: ";
            cin >> amount;
            kingdoms[player].getLeader().improveLeadership(amount);
            break;
        }
        case 9: {
            int amount;
            cout << "Enter amount to change popularity: ";
            cin >> amount;
            kingdoms[player].getLeader().changePopularity(amount);
            break;
        }
        case 10:
            kingdoms[player].getLeader().displayStatus();
            break;
        case 11: {
            int amount;
            cout << "Enter amount of gold to add: ";
            cin >> amount;
            kingdoms[player].getEconomy().addGold(amount);
            break;
        }
        case 12: {
            int amount;
            cout << "Enter amount of gold to spend: ";
            cin >> amount;
            kingdoms[player].getEconomy().spendGold(amount);
            break;
        }
        case 13: {
            int amount;
            cout << "Enter amount of food to add: ";
            cin >> amount;
            kingdoms[player].getEconomy().addFood(amount);
            break;
        }
        case 14: {
            int amount;
            cout << "Enter amount of food to consume: ";
            cin >> amount;
            kingdoms[player].getEconomy().consumeFood(amount);
            break;
        }
        case 15:
            kingdoms[player].getEconomy().displayStatus();
            break;
        case 16: {
            int amount;
            cout << "Enter loan amount: ";
            cin >> amount;
            kingdoms[player].getBanking().issueLoan(amount);
            break;
        }
        case 17: {
            int amount;
            cout << "Enter repayment amount: ";
            cin >> amount;
            kingdoms[player].getBanking().repayLoan(amount);
            break;
        }
        case 18: {
            int rate;
            cout << "Enter new interest rate: ";
            cin >> rate;
            kingdoms[player].getBanking().adjustInterestRate(rate);
            break;
        }
        case 19:
            kingdoms[player].getBanking().displayStatus();
            break;
        case 20: {
            int amount;
            cout << "Enter amount to increase corruption: ";
            cin >> amount;
            kingdoms[player].getCorruption().increaseCorruption(amount);
            break;
        }
        case 21: {
            int amount;
            cout << "Enter amount to decrease corruption: ";
            cin >> amount;
            kingdoms[player].getCorruption().decreaseCorruption(amount);
            break;
        }
        case 22:
            kingdoms[player].getCorruption().displayStatus();
            break;
        case 23: {
            int count;
            cout << "Enter number of nobles to add: ";
            cin >> count;
            kingdoms[player].getSocialStructure().addNobles(count);
            break;
        }
        case 24: {
            int count;
            cout << "Enter number of merchants to add: ";
            cin >> count;
            kingdoms[player].getSocialStructure().addMerchants(count);
            break;
        }
        case 25: {
            int count;
            cout << "Enter number of peasants to add: ";
            cin >> count;
            kingdoms[player].getSocialStructure().addPeasants(count);
            break;
        }
        case 26: {
            int count;
            cout << "Enter number of slaves to add: ";
            cin >> count;
            kingdoms[player].getSocialStructure().addSlaves(count);
            break;
        }
        case 27:
            kingdoms[player].getSocialStructure().displayStatus();
            break;
        case 28: {
            int amount;
            cout << "Enter amount to upgrade walls: ";
            cin >> amount;
            kingdoms[player].getDefense().upgradeWalls(amount);
            break;
        }
        case 29: {
            int count;
            cout << "Enter number of towers to add: ";
            cin >> count;
            kingdoms[player].getDefense().addTowers(count);
            break;
        }
        case 30: {
            int amount;
            cout << "Enter amount to improve traps: ";
            cin >> amount;
            kingdoms[player].getDefense().improveTraps(amount);
            break;
        }
        case 31:
            kingdoms[player].getDefense().displayStatus();
            break;
        case 32: {
            int food, wood, stone, iron;
            cout << "Enter amount of food to gather: ";
            cin >> food;
            cout << "Enter amount of wood to gather: ";
            cin >> wood;
            cout << "Enter amount of stone to gather: ";
            cin >> stone;
            cout << "Enter amount of iron to gather: ";
            cin >> iron;
            kingdoms[player].getResources().gatherResources(food, wood, stone, iron);
            break;
        }
        case 33: {
            int food, wood, stone, iron;
            cout << "Enter amount of food to consume: ";
            cin >> food;
            cout << "Enter amount of wood to consume: ";
            cin >> wood;
            cout << "Enter amount of stone to consume: ";
            cin >> stone;
            cout << "Enter amount of iron to consume: ";
            cin >> iron;
            kingdoms[player].getResources().consumeResources(food, wood, stone, iron);
            break;
        }
        case 34: {
            int food, wood, stone, iron;
            cout << "Enter amount of food to trade: ";
            cin >> food;
            cout << "Enter amount of wood to trade: ";
            cin >> wood;
            cout << "Enter amount of stone to trade: ";
            cin >> stone;
            cout << "Enter amount of iron to trade: ";
            cin >> iron;
            int gold = kingdoms[player].getEconomy().getGold();
            kingdoms[player].getResources().tradeResources(gold, food, wood, stone, iron);
            kingdoms[player].getEconomy().setGold(gold);
            cout << "Gold after trade: " << gold << endl;
            break;
        }
        case 35:
            kingdoms[player].getResources().displayStatus();
            break;
        case 36:
            GameSaver::saveGame("save.txt", kingdoms, MAX_KINGDOMS);
            break;
        case 37:{
            GameSaver::loadGame("save.txt", kingdoms, MAX_KINGDOMS);
            cout << "Game loaded successfully" << endl;
            break;
        }
        case 38: {
            int losses;
            cout << "Enter number of casualties: ";
            cin >> losses;
            kingdoms[player].getArmy().applyCasualties(losses);
            break;
        }
        case 39: {
            int receiverID;
            string message;
            cout << "Enter receiver player ID: ";
            cin >> receiverID;
            cout << "Enter message: ";
            cin.ignore();
            getline(cin, message);
            comm.sendMessage(kingdoms[player].getPlayerID(), receiverID, message);
            break;
        }
        case 40:
            comm.displayMessages(kingdoms[player].getPlayerID());
            break;
        case 41: {
            int player2;
            string terms;
            cout << "Enter player ID to ally with: ";
            cin >> player2;
            cout << "Enter alliance terms: ";
            cin.ignore();
            getline(cin, terms);
            alliance.formAlliance(kingdoms[player].getPlayerID(), player2, terms);
            break;
        }
        case 42: {
            int allianceID;
            cout << "Enter alliance ID to break: ";
            cin >> allianceID;
            alliance.breakAlliance(allianceID, kingdoms, MAX_KINGDOMS);
            break;
        }
        case 43: {
            int player2, amount1, amount2;
            string type1, type2;
            cout << "Enter player ID to trade with: ";
            cin >> player2;
            cout << "Enter resource to give (food/wood/stone/iron): ";
            cin >> type1;
            cout << "Enter amount to give: ";
            cin >> amount1;
            cout << "Enter resource to receive (food/wood/stone/iron): ";
            cin >> type2;
            cout << "Enter amount to receive: ";
            cin >> amount2;
            ResourceType t1 = (type1[0] == 'f') ? FOOD : (type1[0] == 'w') ? WOOD : (type1[0] == 's') ? STONE : IRON;
            ResourceType t2 = (type2[0] == 'f') ? FOOD : (type2[0] == 'w') ? WOOD : (type2[0] == 's') ? STONE : IRON;
            if (market.tradeResources(kingdoms[player].getPlayerID(), player2, t1, amount1, t2, amount2)) {
                cout << "Trade successful" << endl;
            }
            else {
                cout << "Trade failed" << endl;
            }
            break;
        }
        case 44: {
            int player2, amount;
            string type;
            cout << "Enter player ID to smuggle to: ";
            cin >> player2;
            cout << "Enter resource to smuggle (food/wood/stone/iron): ";
            cin >> type;
            cout << "Enter amount: ";
            cin >> amount;
            ResourceType t = (type[0] == 'f') ? FOOD : (type[0] == 'w') ? WOOD : (type[0] == 's') ? STONE : IRON;
            if (market.smuggleResources(kingdoms[player].getPlayerID(), player2, t, amount)) {
                cout << "Smuggling successful" << endl;
            }
            else {
                cout << "Smuggling failed" << endl;
            }
            break;
        }
        case 45: {
            int defenderID;
            cout << "Enter player ID to attack: ";
            cin >> defenderID;
            if (conflict.startBattle(kingdoms[player].getPlayerID(), defenderID)) {
                cout << "Attack successful" << endl;
            }
            else {
                cout << "Attack failed" << endl;
            }
            break;
        }
        case 46: {
            int allyID;
            cout << "Enter ally ID to betray: ";
            cin >> allyID;
            if (conflict.betrayAlliance(kingdoms[player].getPlayerID(), allyID)) {
                cout << "Betrayal successful" << endl;
            }
            else {
                cout << "Betrayal failed" << endl;
            }
            break;
        }
        case 47: {
            int x, y;
            cout << "Enter x y coordinates: ";
            cin >> x >> y;
            map.moveArmy(kingdoms[player].getPlayerID(), x, y);
            break;
        }
        case 48:
            map.displayMap();
            break;
        case 49:
            cout << "Exiting the program." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
            break;
        }

        if (choice != 49) {
            checkRandomEvent(kingdoms[player].getEconomy(), kingdoms[player].getPopulation(), kingdoms[player].getArmy());
        }

        player = (player + 1) % MAX_KINGDOMS;

    } while (choice != 49);
    system("pause");
    return 0;
}