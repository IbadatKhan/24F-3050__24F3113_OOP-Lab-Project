#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Stronghold.h"

using namespace std;

Alliance::Alliance() : treatyCount(0), nextID(1) {
    for (int i = 0; i < MAX_TREATIES; i++) {
        treaties[i].id = 0;
        treaties[i].player1 = 0;
        treaties[i].player2 = 0;
        treaties[i].terms[0] = '\0';
    }
}

void Alliance::formAlliance(int player1, int player2, const string& terms) {
    if (treatyCount < MAX_TREATIES) {
        treaties[treatyCount].id = nextID++;
        treaties[treatyCount].player1 = player1;
        treaties[treatyCount].player2 = player2;
        strncpy(treaties[treatyCount].terms, terms.c_str(), 99);
        treaties[treatyCount].terms[99] = '\0';
        string log = "player" + to_string(player1) + ",player" + to_string(player2) + ":alliance_formed:" + terms;
        GameSaver::logTreaty(log);
        treatyCount++;
        cout << "Alliance formed between player" << player1 << " and player" << player2 << endl;
    }
    else {
        cout << "Treaty limit reached." << endl;
    }
}

void Alliance::breakAlliance(int allianceID, Kingdom* kingdoms, int maxKingdoms) {
    for (int i = 0; i < treatyCount; i++) {
        if (treaties[i].id == allianceID) {
            string log = "player" + to_string(treaties[i].player1) + ",player" + to_string(treaties[i].player2) + ":alliance_broken";
            GameSaver::logTreaty(log);
            for (int j = 0; j < maxKingdoms; j++) {
                if (kingdoms[j].getPlayerID() == treaties[i].player1 || kingdoms[j].getPlayerID() == treaties[i].player2) {
                    kingdoms[j].getPopulation().updateUnrest();
                }
            }
            treaties[i] = treaties[treatyCount - 1];
            treatyCount--;
            cout << "Alliance " << allianceID << " broken." << endl;
            return;
        }
    }
    cout << "Alliance ID not found." << endl;
}

void Alliance::displayAlliances(int playerID) const {
    bool hasAlliances = false;
    for (int i = 0; i < treatyCount; i++) {
        if (treaties[i].player1 == playerID || treaties[i].player2 == playerID) {
            int other = (treaties[i].player1 == playerID) ? treaties[i].player2 : treaties[i].player1;
            cout << "Alliance " << treaties[i].id << " with player" << other << ": " << treaties[i].terms << endl;
            hasAlliances = true;
        }
    }
    if (!hasAlliances) {
        cout << "No active alliances." << endl;
    }
}