#include <iostream>
#include "Stronghold.h"

using namespace std;

ResourceEcosystem::ResourceEcosystem() : food(0), wood(0), stone(0), iron(0) {}

void ResourceEcosystem::gatherFood(int amount) {
    if (amount > 0) {
        food += amount;
        cout << amount << " units of food gathered." << endl;
    }
    else {
        cout << "Invalid amount." << endl;
    }
}

void ResourceEcosystem::gatherWood(int amount) {
    if (amount > 0) {
        wood += amount;
        cout << amount << " units of wood gathered." << endl;
    }
    else {
        cout << "Invalid amount." << endl;
    }
}

void ResourceEcosystem::gatherStone(int amount) {
    if (amount > 0) {
        stone += amount;
        cout << amount << " units of stone gathered." << endl;
    }
    else {
        cout << "Invalid amount." << endl;
    }
}

void ResourceEcosystem::gatherIron(int amount) {
    if (amount > 0) {
        iron += amount;
        cout << amount << " units of iron gathered." << endl;
    }
    else {
        cout << "Invalid amount." << endl;
    }
}

void ResourceEcosystem::consumeFood(int amount) {
    if (amount > 0 && amount <= food) {
        food -= amount;
        cout << amount << " units of food consumed." << endl;
    }
    else {
        cout << "Not enough food to consume." << endl;
    }
}

void ResourceEcosystem::consumeWood(int amount) {
    if (amount > 0 && amount <= wood) {
        wood -= amount;
        cout << amount << " units of wood consumed." << endl;
    }
    else {
        cout << "Not enough wood to consume." << endl;
    }
}

void ResourceEcosystem::consumeStone(int amount) {
    if (amount > 0 && amount <= stone) {
        stone -= amount;
        cout << amount << " units of stone consumed." << endl;
    }
    else {
        cout << "Not enough stone to consume." << endl;
    }
}

void ResourceEcosystem::consumeIron(int amount) {
    if (amount > 0 && amount <= iron) {
        iron -= amount;
        cout << amount << " units of iron consumed." << endl;
    }
    else {
        cout << "Not enough iron to consume." << endl;
    }
}

void ResourceEcosystem::gatherResources(int f, int w, int s, int i) {
    gatherFood(f);
    gatherWood(w);
    gatherStone(s);
    gatherIron(i);
}

void ResourceEcosystem::consumeResources(int f, int w, int s, int i) {
    consumeFood(f);
    consumeWood(w);
    consumeStone(s);
    consumeIron(i);
}

void ResourceEcosystem::tradeResources(int& gold, int f, int w, int s, int i) {
    int cost = f * 2 + w * 3 + s * 5 + i * 10;
    if (gold >= cost) {
        gold -= cost;
        food += f;
        wood += w;
        stone += s;
        iron += i;
        cout << "Trade successful! Resources added to your stock." << endl;
    }
    else {
        cout << "Not enough gold for this trade." << endl;
    }
}

void ResourceEcosystem::displayStatus() const {
    cout << "---- Resource Ecosystem Status ----" << endl;
    cout << "Food: " << food << endl;
    cout << "Wood: " << wood << endl;
    cout << "Stone: " << stone << endl;
    cout << "Iron: " << iron << endl;
}

// Added for Phase 2: Unified resource access for Market and Conflict
int ResourceEcosystem::getResource(ResourceType type) const {
    switch (type) {
    case FOOD: return food;
    case WOOD: return wood;
    case STONE: return stone;
    case IRON: return iron;
    default: return 0;
    }
}