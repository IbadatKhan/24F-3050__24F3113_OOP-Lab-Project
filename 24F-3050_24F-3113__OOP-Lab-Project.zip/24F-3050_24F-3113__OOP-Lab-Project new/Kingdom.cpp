#include <iostream>
#include "Stronghold.h"

using namespace std;

Kingdom::Kingdom(int id) : playerID(id), resources(), army(), population(), economy(), leader(), socialStructure(), banking(), corruption(), defense() {}

int Kingdom::getPlayerID() const { return playerID; }
ResourceEcosystem& Kingdom::getResources() const { return const_cast<ResourceEcosystem&>(resources); }
Army& Kingdom::getArmy() const { return const_cast<Army&>(army); }
Population& Kingdom::getPopulation() const { return const_cast<Population&>(population); }
Economy& Kingdom::getEconomy() const { return const_cast<Economy&>(economy); }
Leader& Kingdom::getLeader() const { return const_cast<Leader&>(leader); }
SocialStructure& Kingdom::getSocialStructure() const { return const_cast<SocialStructure&>(socialStructure); }
Banking& Kingdom::getBanking() const { return const_cast<Banking&>(banking); }
Corruption& Kingdom::getCorruption() const { return const_cast<Corruption&>(corruption); }
Defense& Kingdom::getDefense() const { return const_cast<Defense&>(defense); }